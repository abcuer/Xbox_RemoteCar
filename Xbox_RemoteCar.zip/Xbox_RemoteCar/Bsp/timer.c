#include "timer.h"

void timer0_init(void)
{
	NVIC_ClearPendingIRQ(TIMER_0_INST_INT_IRQN);
	NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);	
}

void timer1_init(void)
{
	NVIC_ClearPendingIRQ(TIMER_1_INST_INT_IRQN);
	NVIC_EnableIRQ(TIMER_1_INST_INT_IRQN);
}

// pid����
void TIMER_0_INST_IRQHandler(void)   //PID����  10ms  ���ȼ����
{
	if(DL_TimerA_getPendingInterrupt(TIMER_0_INST))
	{
		if(DL_TIMER_IIDX_ZERO) 
		{	
			speed_cal(0.2); 
			PID_select();
		}
	}
} 

void TIMER_1_INST_IRQHandler(void)	// ������  10ms  ���ȼ���
{
	if(DL_TimerG_getPendingInterrupt(TIMER_1_INST))
	{
		if(DL_TIMER_IIDX_LOAD)
		{	
			if (start_flag == 1 && first_flag == 0)   capture_initial_yaw();
			UpdateSoundLight();
		}
	}
}