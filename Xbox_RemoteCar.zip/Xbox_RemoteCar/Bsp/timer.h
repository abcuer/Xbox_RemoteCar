#ifndef _timer_h
#define _timer_h

#include "headfile.h"

void timer0_init(void);
void timer1_init(void);
#endif