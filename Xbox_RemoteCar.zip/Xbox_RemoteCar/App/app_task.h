#ifndef _task_h_
#define _task_h_


void Task_1(void);
void Task_2(void);

#endif