#ifndef _position_h_
#define _position_h_

void Task_select(void);
void capture_initial_yaw(void);
void SoundLight(void);
void UpdateSoundLight(void);
void params_clear(void);

#endif