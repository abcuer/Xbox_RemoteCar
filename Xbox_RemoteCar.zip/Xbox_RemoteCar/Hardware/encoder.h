#ifndef _encoder_h
#define _encoder_h

#include "headfile.h"

void encoder_Init(void);

#endif