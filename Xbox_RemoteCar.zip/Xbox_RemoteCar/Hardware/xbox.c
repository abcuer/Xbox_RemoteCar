#include "headfile.h"

XBOX_t xbox;

volatile uint8_t xbox_buf[8];
volatile uint8_t xbox_idx = 0;

void xbox_init(void)
{
    NVIC_ClearPendingIRQ(UART_2_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
}

void UART_2_INST_IRQHandler(void)
{
    if (DL_UART_getPendingInterrupt(UART_2_INST) == DL_UART_IIDX_RX)
    {
        uint8_t byte = DL_UART_Main_receiveData(UART_2_INST);

        if (xbox_idx == 0 && byte != 0xAA)
            return;
        if (xbox_idx == 5 && byte != 0x55)
        {
            xbox_idx = 0;
            return;
        }
        xbox_buf[xbox_idx++] = byte;

        // ���� 6 �ֽ�
        if (xbox_idx == 6)
        {
            if (xbox_buf[0] == 0xAA && xbox_buf[5] == 0x55)
            {
                xbox.Lspd = (int16_t)((xbox_buf[1] << 8) | xbox_buf[2]);
                xbox.Rspd = (int16_t)((xbox_buf[3] << 8) | xbox_buf[4]);

                if (xbox.Lspd > MAX_SPEED)  xbox.Lspd = MAX_SPEED;
                if (xbox.Lspd < -MAX_SPEED) xbox.Lspd = -MAX_SPEED;
                if (xbox.Rspd > MAX_SPEED)  xbox.Rspd = MAX_SPEED;
                if (xbox.Rspd < -MAX_SPEED) xbox.Rspd = -MAX_SPEED;
            }
			Motor_left_Control(xbox.Lspd);
			Motor_right_Control(xbox.Rspd);

            xbox_idx = 0;
        }
    }
}
