#include "headfile.h"

volatile uint8_t xbox_buf[8];
volatile uint8_t xbox_idx = 0;


uint8_t L_dir = 0;
int16_t L_spd = 0;
uint8_t R_dir = 0;
int16_t R_spd = 0;

void xbox_init(void)
{
    NVIC_ClearPendingIRQ(UART_2_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
}

void UART_2_INST_IRQHandler(void)
{
    if (DL_UART_getPendingInterrupt(UART_2_INST) == DL_UART_IIDX_RX)
    {
        uint8_t byte = DL_UART_Main_receiveData(UART_2_INST);

        if (xbox_idx == 0 && byte != 0xAA)
            return;
        if (xbox_idx == 5 && byte != 0x55)
        {
            xbox_idx = 0;
            return;
        }
        xbox_buf[xbox_idx++] = byte;

        // ���� 6 �ֽ�
        if (xbox_idx == 6)
        {
            if (xbox_buf[0] == 0xAA && xbox_buf[5] == 0x55)
            {
                int16_t L_spd = (int16_t)((xbox_buf[1] << 8) | xbox_buf[2]);
                int16_t R_spd = (int16_t)((xbox_buf[3] << 8) | xbox_buf[4]);

                if (L_spd > MAX_SPEED)  L_spd = MAX_SPEED;
                if (L_spd < -MAX_SPEED) L_spd = -MAX_SPEED;
                if (R_spd > MAX_SPEED)  R_spd = MAX_SPEED;
                if (R_spd < -MAX_SPEED) R_spd = -MAX_SPEED;

                Motor_left_Control(L_spd);
                Motor_right_Control(R_spd);
            }

            xbox_idx = 0;
        }
    }
}
