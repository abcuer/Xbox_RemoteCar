#include "headfile.h"

void HC06Init(void)
{
	NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);
	NVIC_EnableIRQ(UART_0_INST_INT_IRQN);
}

void UART_0_INST_IRQHandler(void)
{
    if(DL_UART_getPendingInterrupt(UART_0_INST) == DL_UART_IIDX_RX)
    {
        uint8_t recv_data = DL_UART_Main_receiveData(UART_0_INST);
		switch(recv_data)
		{
			case 0x00: 		CarStop(); 			break;
			/* ǰ */
			case 0x01:		CarForward();		break;
			/* �� */
			case 0x05:		CarBackward();		break;
			/* �� */
			case 0x03:		CarTurnRight();	 	break;
			/* �� */	
			case 0x07:		CarTurnLeft();		break;
			/* ��ǰ�� */
			case 0x08:		CarLeftForward();	break;
			/* ��ǰ�� */
			case 0x02:		CarRightForward();	break;
			/* ��� */
			case 0x06:		CarLeftBackward();	break;
			/* �Һ� */
			case 0x04:		CarRightBackward();	break;
			/* ���� */
			default:		CarStop();			break;
		}
    }
}

