#ifndef _buzzer_h
#define _buzzer_h
#include "ti_msp_dl_config.h"
#include "board.h"

void Buzzer_ON(void);
void Buzzer_OFF(void);

#endif