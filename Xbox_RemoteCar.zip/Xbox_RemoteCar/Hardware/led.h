#ifndef _led_h_
#define _led_h_
#include "ti_msp_dl_config.h"
#include "board.h"

void LED_Blue_ON(void);
void LED_Blue_OFF(void);
void LED_Green_ON(void);
void LED_Green_OFF(void);

#endif