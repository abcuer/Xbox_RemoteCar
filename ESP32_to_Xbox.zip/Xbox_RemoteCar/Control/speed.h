#ifndef _speed_h
#define _speed_h

void speed_cal(float filter_alpha);
int Velocity_A(int TargetVelocity, int CurrentVelocity);
int Velocity_B(int TargetVelocity, int CurrentVelocity);
/***  ���������õ��ٶȻ�  ***/
void speedloop_pid_control(int speed_tar, int base);
 /***  �ٶȻ�ת��90��  ***/
void turn_90_control(int speed_tar, int offset);
 /***  �ٶȻ�  ***/
void speed_pid_control(int Ltar, int Rtar);
#endif