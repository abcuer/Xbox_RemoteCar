#ifndef _timer_h
#define _timer_h

#include "ti_msp_dl_config.h"
#include "board.h"

void timer0_init(void);
void timer1_init(void);
#endif