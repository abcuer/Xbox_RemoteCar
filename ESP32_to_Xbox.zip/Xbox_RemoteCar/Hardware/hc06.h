#ifndef HC06_H
#define HC06_H

#include "stdint.h"
void HC06Init(void);

#endif