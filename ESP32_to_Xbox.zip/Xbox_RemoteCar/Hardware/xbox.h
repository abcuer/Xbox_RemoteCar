#ifndef _hc05_h
#define _hc05_h
#include "stdint.h"

#define MAX_SPEED 640

typedef struct
{
	int16_t Lspd;
	int16_t Rspd;
}XBOX_t;

void xbox_init(void);
void uart_send_bytes(uint8_t *buf, uint16_t len);
void send_cmd(uint8_t cmd, uint8_t *data, uint8_t len);
void process_cmd(uint8_t task, uint8_t *data, uint8_t len);

#endif