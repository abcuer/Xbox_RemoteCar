#ifndef DEMO_H
#define DEMO_H

#include <Arduino.h>
#include <drivers/XboxSeriesXControllerESP32_asukiaaa.hpp>

void demoVibration();
void demoVibration_2();

extern XboxSeriesXControllerESP32_asukiaaa::Core xboxController;

#endif