#include <Arduino.h>
#include <demo/demo.h>
#include <drivers/XboxSeriesXControllerESP32_asukiaaa.hpp>

#define DEADZONE 2000                   
#define MIN_DEADZONE 500
#define MAX_SPEED 300                     

HardwareSerial CarSerial(2);
// Required to replace with your xbox address
// 需要在此替换成自己的手柄蓝牙MAC地址
XboxSeriesXControllerESP32_asukiaaa::Core 
  xboxController("8a:6f:96:74:17:a6");

String xbox_string()
{
  String str = String(xboxController.xboxNotif.btnY) + "," +
               String(xboxController.xboxNotif.btnX) + "," +
               String(xboxController.xboxNotif.btnB) + "," +
               String(xboxController.xboxNotif.btnA) + "," +
               String(xboxController.xboxNotif.btnLB) + "," +
               String(xboxController.xboxNotif.btnRB) + "," +
               String(xboxController.xboxNotif.btnSelect) + "," +
               String(xboxController.xboxNotif.btnStart) + "," +
               String(xboxController.xboxNotif.btnXbox) + "," +
               String(xboxController.xboxNotif.btnShare) + "," +
               String(xboxController.xboxNotif.btnLS) + "," +
               String(xboxController.xboxNotif.btnRS) + "," +
               String(xboxController.xboxNotif.btnDirUp) + "," +
               String(xboxController.xboxNotif.btnDirRight) + "," +
               String(xboxController.xboxNotif.btnDirDown) + "," +
               String(xboxController.xboxNotif.btnDirLeft) + "," +
               String(xboxController.xboxNotif.joyLHori) + "," +
               String(xboxController.xboxNotif.joyLVert) + "," +
               String(xboxController.xboxNotif.joyRHori) + "," +
               String(xboxController.xboxNotif.joyRVert) + "," +
               String(xboxController.xboxNotif.trigLT) + "," +
               String(xboxController.xboxNotif.trigRT) + "\n";
  return str;
};

int16_t mapStick(uint16_t raw)
{
    return (int32_t)raw - 32768;  // 得到 -32768 ~ +32767
}
void setup()
{
  Serial.begin(115200);
  CarSerial.begin(115200, SERIAL_8N1, 16, 17);
  Serial.println("Starting NimBLE Client");
  xboxController.begin();
}

void loop()
{
  xboxController.onLoop();
  Serial.print(xbox_string());
  if (xboxController.isConnected() && !xboxController.isWaitingForFirstNotification()) 
  {
    uint16_t rawX = xboxController.xboxNotif.joyLHori;
    uint16_t rawY = xboxController.xboxNotif.joyLVert;
    // 转成 -32768 ~ +32767
    int32_t stickLX = (int32_t)rawX - 32768;
    int32_t stickLY = (int32_t)rawY - 32768;
    // 加死区
    if (abs(stickLX) < DEADZONE) stickLX = 0;
    if (abs(stickLY) < DEADZONE) stickLY = 0;
    // 转成车速
    int16_t speed = map(stickLY, -32768, 32767, -1000, 1000); // 前正
    speed = -speed;
    int16_t turn  = map(stickLX, -32768, 32767, -600, 600);   // 右正
    turn = -turn;
    // 差速控制
    int16_t left_speed  = speed - turn;
    int16_t right_speed = speed + turn;
    // 限幅
    left_speed  = constrain(left_speed,  -1000, 1000);
    right_speed = constrain(right_speed, -1000, 1000);
    // 打包发送
    uint8_t pkt[6] = {0xAA};
    pkt[1] = highByte(left_speed);
    pkt[2] = lowByte(left_speed);
    pkt[3] = highByte(right_speed);
    pkt[4] = lowByte(right_speed);
    pkt[5] = 0x55;

    CarSerial.write(pkt, 6);
  }
  else
  {
    if (xboxController.getCountFailedConnection() > 2)
    {
      ESP.restart();
    }
  }
}




    // // 振动反馈（开起来更爽）
    // static uint32_t lastVib = 0;
    // if (millis() - lastVib > 40) {
    //   XboxSeriesXHIDReportBuilder_asukiaaa::ReportBase vib;
    //   vib.setAllOff();
    //   vib.v.select.left = vib.v.select.right = true;
    //   vib.v.power.left  = map(abs(left),  0, 65535, 0, 100);
    //   vib.v.power.right = map(abs(right), 0, 65535, 0, 100);
    //   vib.v.timeActive = 8;
    //   xboxController.writeHIDReport(vib);
    //   lastVib = millis();
    // }